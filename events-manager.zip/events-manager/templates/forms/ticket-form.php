<?php 
//DEPRECATED, MODIFY THE INCLUDED TEMPLATE INSTEAD
em_locate_template('forms/event/bookings-ticket-form.php', true);